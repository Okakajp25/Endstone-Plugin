from endstone_my_plugin.my_plugin import MyPlugin

__all__ = ["MyPlugin"]